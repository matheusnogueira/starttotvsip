CDBF for Windows.
Version 1.20 shareware

The CDBF program is simultaneously a viewer and DBF-format files editor. 
In contrast to many similar programs, CDBF makes no distinction between 
viewing and editing modes - in both modes you are able to fulfil any 
actions with the database in use. All functions of the CDBF program 
work in an order much faster than those of similar programs.

The program also allows viewing and editing of memo fields in dBase III, 
dBase IV, FoxPro, and VFP formats. A memo field type is identified automatically.

It has a huge number of unique features. CDBF allows users to export data 
to TXT, PRG, XSL, SQL, DBF formats. Besides which, the features can be expanded 
due to plugins support.

CDBF is not freeware or public domain. This is a copyrighted software.
The different ways to purchase and register CDBF your can find here:
	http://www.whitetown.com/order.php3

For more information see license.txt.


THE  AUTHOR  WILL  NOT  BE  LIABLE  FOR ANY SPECIAL, INCIDENTAL,
CONSEQUENTIAL, INDIRECT OR SIMILAR DAMAGES  DUE  TO LOSS OF DATA
OR ANY OTHER REASON.

For feedback, questions and any comments:
- Email     support@whitetown.com
- WWW       http://www.whitetown.com

Thank you very much for using CDBF.
